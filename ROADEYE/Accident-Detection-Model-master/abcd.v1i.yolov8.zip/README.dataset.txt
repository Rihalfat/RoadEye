# Accident detection model > 2023-04-19 9:03pm
https://universe.roboflow.com/object-detection/accident-detection-model

Provided by a Roboflow user
License: CC BY 4.0

